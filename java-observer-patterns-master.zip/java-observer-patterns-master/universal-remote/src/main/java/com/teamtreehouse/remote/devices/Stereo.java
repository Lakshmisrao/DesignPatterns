package com.teamtreehouse.remote.devices;

public class Stereo extends Device {

    public void volumeUp() {
        announce("Volume turned up");
    }

}
