package com.teamtreehouse.restaurant.tables;

public enum Status {
    OCCUPIED,
    FINISHED,
    CLOSING_BILL,
    NEEDS_BUSSING,
    BUSSING,
    AVAILABLE
}
