# Observer Design Pattern Using Java

This repository contains several modules that are intended to be used alongside the Treehouse workshop [Observer Design Pattern Using Java](https://teamtreehouse.com/library/observer-design-pattern-using-java)

This repo is tagged based on videos.  So `s1v3` will be at the start of the 1st stage 3rd video.

To switch to that video simply checkout that tag like so:

```
git checkout s1v3
```
