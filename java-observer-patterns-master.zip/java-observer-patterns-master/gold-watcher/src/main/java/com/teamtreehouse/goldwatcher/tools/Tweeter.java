package com.teamtreehouse.goldwatcher.tools;

public class Tweeter {

    public static void tweet(String message) {
        System.out.println("Tweet tweet: " + message);
    }

}
