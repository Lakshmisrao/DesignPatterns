package com.teamtreehouse.goldwatcher;

public class GoldMedalReporter {

    public void reportWin(String country) {
        System.out.println("Gold medal awarded to " + country);
    }



}
