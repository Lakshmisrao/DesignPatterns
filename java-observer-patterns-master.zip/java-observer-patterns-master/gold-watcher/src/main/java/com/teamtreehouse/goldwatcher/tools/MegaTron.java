package com.teamtreehouse.goldwatcher.tools;

public class MegaTron {

    public void display(String message) {
        System.out.println("MegaTron:  Let's hear it for " + message);
    }

}
